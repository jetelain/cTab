name = "cTab - Blue Force Tracking";
picture = "cTab_ico.paa";
actionName = "Website";
action = "https://github.com/DPSO/cTab-1";
overview = "Commander's Tablet / FBCB2 - Blue Force Tracking<br />Battlefield tablet to access real time intel and blue force tracker.<br />BI Thread: http://forums.bistudio.com/showthread.php?163030";
tooltip = "Commander's Tablet / FBCB2 - Blue Force Tracking";
author = "Riouken & Gundy";
